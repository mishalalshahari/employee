var express = require('express');
var router = express.Router();

/* GET users listing. */
router.get('/', function(req, res, next) {
  res.send('hello gaddari karbe');
});

router.get('/up', function(req, res, next) {
  res.send('ka re');
});

router.get('/data/:id', function(req, res, next) {
  if(req.params.id<5){
    res.send('Less than 5');
    return;
  }
  //res.send(req.params.id);

});

module.exports = router;